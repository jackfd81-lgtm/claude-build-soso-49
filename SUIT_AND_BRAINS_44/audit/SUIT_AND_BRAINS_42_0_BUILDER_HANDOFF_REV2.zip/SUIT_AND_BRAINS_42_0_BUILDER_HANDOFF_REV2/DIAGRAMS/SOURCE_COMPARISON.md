# Build 040 diagrams — source-level comparison for Suit and Brains 42.0

**Evidence:** Original user-provided diagrams preserved without alteration. Comparison based on inspected Build 040/merged 040.1 source paths. This is not a claim of executed 42.0.

| Diagram element | Finding | Source evidence |
|---|---|---|
| Operator → Main AI → Closet | PARTIALLY_MATCHES | `build040_runtime/closet.py; build040_runtime/online_ai.py` |
| Closet → Continuity → Brains → Suit → CRAM-PU → blocks | SCHEMATIC_NOT_LITERAL | `build040_runtime/closet.py; brains_49_runtime.py; learning_loop.py` |
| SoSo Continuity sessions + provenance | SOURCE_MATCH | `build040_runtime/soso_continuity.py` |
| Lower49/Higher49 + ExperienceEngine | SOURCE_MATCH_WITH_LIMIT | `build040_runtime/brains_49_runtime.py` |
| Suit grants/child attenuation/revocation | SOURCE_MATCH_WITH_RISK | `build040_runtime/suit_runtime.py` |
| CRAM-PU HOT/WARM/COOL + outbox | SOURCE_MATCH_WITH_LIMIT | `crampu/controller.py` |
| Big49/Small49 2208 logical blocks | SOURCE_MATCH_WITH_LIMIT | `crampu/controller.py; build040_runtime/brains_49_runtime.py` |
| U13 evaluation → U11 gaps → U15 reuse → U12 selection | SOURCE_MATCH | `build040_runtime/learning_loop.py` |
| Assisted AI hint → U14 history learning → Big49 write | SOURCE_MATCH_WITH_CAUSAL_GAP | `build040_runtime/learning_loop.py` |
| Read-only profile lookup before transfer | SOURCE_MATCH_WITH_LIMIT | `build040_runtime/learning_loop.py` |
| Learned profile committed and available for reuse | IMPLEMENTED_PATH_NOT_FULLY_QUALIFIED | `build040_runtime/learning_loop.py; crampu/build030_bridge.py` |
| Diagram date 2024-05-18 | CONFLICT_UNRESOLVED | `User-supplied image metadata/text` |
| Build 040 diagram vs Suit and Brains 42.0 target | PROPOSED_TARGET | `User-supplied images; Build040 sources` |

## Builder interpretation constraints

- The first diagram is a conceptual architecture map, **not** an exact enforced linear call graph. Closet can call Suit directly; Brains and LearningLoop hold Suit and Continuity references.
- The second diagram is broadly aligned with U13 → U11 → optional U15 → U12 and separate U14(history) → persisted profile, but the AI hint is not passed as an input to U14 in the inspected code.
- Profile storage, profile reuse and functional learning improvement are separate acceptance criteria.
- The date shown on the learning diagram (2024-05-18) is not accepted as evidence of source provenance.
- All authority labels on diagrams are design claims; source and tests must verify enforcement.
- Keep Build 040 and PH6 separate.

## Source comparison records

`SOURCE_COMPARISON.json` includes individual findings, supporting source files, evidence and explicit builder requirements.
