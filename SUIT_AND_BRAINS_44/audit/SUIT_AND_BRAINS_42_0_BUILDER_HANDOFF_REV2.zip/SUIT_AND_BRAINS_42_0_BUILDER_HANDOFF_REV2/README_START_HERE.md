# Suit and Brains 42.0 — builder handoff

1. Upload this ZIP to the other ChatGPT (or extract and upload the individual source archives if it cannot inspect nested ZIPs).
2. Ask it to read `BUILDER_INSTRUCTIONS/PASTE_THIS_INTO_OTHER_CHATGPT.md` and implement Suit and Brains 42.0 using `SOURCE_ARCHIVES/` as code baselines.
3. `SOURCE_EVIDENCE/` and `REGISTRIES/` provide inventory and test-disclosure evidence; they are not substitutes for source execution.
4. Do not treat this handoff as a completed Build 42.0 implementation.

**Source lineage:** Gemini 9 -> merged 040.1 candidate; learning-qualified archive is an additional variant requiring comparison.

## Revision 2: user-supplied architecture diagrams

Two original PNGs are preserved under `DIAGRAMS/`, with 13 source-comparison records. Read them before using the diagrams as implementation contracts. This revision does not implement Suit and Brains 42.0.
