# SUIT AND BRAINS 42.0 — EXECUTABLE BUILDER DIRECTIVE

**Project name:** SUIT_AND_BRAINS_42_0  
**Builder role:** lead software engineer, runtime integrator, cognitive systems engineer, storage engineer, security tester, test engineer.  
**Task:** deliver a working, independently qualified standalone Suit and Brains 42.0 source tree and installable release. This document is an implementation contract, not evidence that Build 42.0 already exists.

## 0. Immediate instruction to the receiving ChatGPT

You are to **BUILD** Suit and Brains 42.0. Do not respond only with a review, a plan, a summary, or a list of recommendations. Inspect the attached source archives and registries, reconcile the baseline, implement the code, run the tests you can actually run, and return a complete source ZIP, reproducible tests, qualification evidence, and a change report. If your environment cannot execute, state the exact constraint and provide all complete source and commands without claiming tests passed. Never fabricate results. Do not ask for unrelated historical documents when work can proceed.

**Order of operations:** (1) verify archive hashes and compare variants; (2) choose a declared baseline and preserve unchanged legacy behavior; (3) implement the minimum viable complete vertical path; (4) add behavioral tests; (5) run cold/learned/restart/ablation/novel-transfer comparisons; (6) implement independent Orange Pi grading; (7) package Pi deployment; (8) publish an evidence-backed release. Continue implementation despite Class 2/3 gaps.

## 1. Supplied source packages and reconciliation

`SOURCE_ARCHIVES/SUIT_AND_BRAINS_BUILD040_GEMINI 9.zip` is the 40.0.0 release. SHA-256 `f721ba433b9ceac155d13e9b10941d6516345e17d3631d6be5cda79b1e5e6996`. It has **332 file entries**.

`SOURCE_ARCHIVES/SUIT_AND_BRAINS_BUILD040_1_MERGED_GEMINI.zip` is the merged 040.1 candidate. SHA-256 `03b22391935915cfa3ef165478f4d1d74a31116f1dce292357c82349dda54336`. It has **335 file entries**. Relative to Release 9: 331 identical files, 3 merged-only paths (`BUILD040_1_EXECUTION_REPORT.json`, `BUILD040_1_README.md`, `tests/test_learning_qualification_0401.py`), one differing shared file (`VERSION.txt`), and zero Release-9-only paths. This is a content comparison, not a claim of production qualification.

`SOURCE_ARCHIVES/SUIT_AND_BRAINS_BUILD040_1_LEARNING_QUALIFIED.zip` is a separate historical learning-qualification artifact, SHA-256 `5bd94ee5adc604936ec6c5d768f21c7895c48894f95aa5b409327d3f80979f7e`. Inspect before deciding whether any implementation differs. Do not blindly concatenate archives or assume newer naming means more functional code.

`SOURCE_EVIDENCE/BUILD040_FORENSIC_EXTRACTION_001.zip` inventories 332 archive files, 2,236 syntactic Python function definitions, 1,642 import statements, 87 test-file paths, zero AST parse errors for Release 9. **Syntactic function definitions are not 98 cognitive slots, and do not prove executable behavior.**

`REGISTRIES/functions_98.json`, `REGISTRIES/functions_98.csv`, `REGISTRIES/SLOTS_98_SOURCE_DISCLOSURE.csv`, `REGISTRIES/memory_positions_2208.csv`, and `REGISTRIES/memory_bucket_summary.json` are baseline indexes. Treat them as inventory evidence; verify their mappings against the source code. `SOURCE_EVIDENCE/BUILD040_98_SLOT_DISCLOSURE.json` is a source-supplied disclosure, not an independent end-to-end behavioral test.

## 2. Scope and system boundaries

Build **standalone SoSo + Lower49 + Higher49 + cognitive memory + SoSo Suit + SoSo Closet + experience learning + optional online AI**. This is not a full PH6 runtime. The user retains control over future PH6 integration. Preserve AUTH:0 advisory isolation and prevent advisory outputs or stored interpretations from becoming PH6 Lane-1 evidence authority. Do not let the standalone implementation become immobilized by PH6 governance paperwork.

**Component roles:**

- **Main AI / SoSo Closet:** bounded request entry, context retrieval, controlled agent invocation, result collection. Source `build040_runtime/closet.py`. Do not conflate Closet with Suit.
- **SoSo Continuity:** SQLite session and event ledger, ordered events, provenance kinds, experience index, interruption/recovery, routing. Source `build040_runtime/soso_continuity.py`.
- **Lower49 / Higher49:** 49 logical slots per tier; source registry `contract/brains_wiring.py`, specialized operations `contract/functions025.py`, `contract/cross_specialty.py`, `contract/disposition_engine.py`; runtime `build040_runtime/brains_49_runtime.py`.
- **SoSo Suit:** agent identity, grants, allowed memory blocks, budgets, child attenuation, revocation and audit. Source `build040_runtime/suit_runtime.py`. Agents invoked by the main AI operate under Suit. Complex independent child agents require explicit main-AI authorization; small bounded helper delegation may be supported only under strictly attenuated parent rights.
- **CRAM-PU:** `crampu/controller.py`, `crampu/build030_bridge.py`; HOT LRU, WARM durable snapshots, COOL SQLite WAL, ownership, transitions and transactional outbox. Keep memory writes and advisory metadata separate from PH6 evidence acceptance.
- **Big49/Small49:** `realcog/ph6_brains_2208.py`; 1,600 Big49 + 608 Small49 logical positions. Capacity is not utilization.
- **Experience and learning:** `build040_runtime/brains_49_runtime.py` (`ExperienceEngine`) and `build040_runtime/learning_loop.py` (`AssistedLearningLoop`). Evaluate actual improvement, not presence of learning-named functions.
- **AI Gateway:** `build040_runtime/online_ai.py`; Gemini/OpenAI/replay/offline; model outputs are advisory and provenance-logged.
- **Precision and testing:** `build040_runtime/precision_105.py`, `precision_105_grader.py`, tests, Orange Pi grader, historical fixtures.

## 3. The 98-function contract

**Verified source inventory:** L01–L49 and U01–U49, 98 registered slots. Source disclosure identifies **21 executable implementations** and **77 default-routed passthroughs**. An `OK` response from a default region handler is not proof that the corresponding cognitive operation was implemented. A `core_specialized` flag is also not proof of implementation.

**Implemented IDs:** `L03 L04 L05 L16 L17 L18 L22 L31 L33 L34 U06 U07 U09 U11 U12 U13 U14 U15 U16 U32 U33`.

**Functions reported exercised in Build 040 suite:** `L03 L04 L16 L17 L18 L22 L31 L33 L34 U09 U11 U12 U13 U14 U15 U16 U32 U33` (18 unique IDs; verify against trace and tests before labeling independently executed). L05, U06, U07 require separate targeted execution checks. The P105 trace identifies 9 functions: L03, L04, L16, L17, L18, L22, L31, U16, U09.

**Seven regions:** Evidence Interface (L01–L07); TOK Representation (L08–L14); Relationship Cortex (L15–L21); Temporal Continuity (L22–L28); Investigation Navigation (L29–L35); Audit Metacognition (L36–L42); AI Closet Gates (L43–L49). Confirm how Higher49 maps to regions in `contract/brains_wiring.py` rather than inventing symmetry.

**Build 42.0 requirement:** keep all 98 IDs registered and stable. For each ID, expose explicit `IMPLEMENTED`, `PASSTHROUGH`, `UNSUPPORTED`, or `EXPERIMENTAL` status; inputs, outputs, side effects, security scope, call graph, memory dependencies, and tests. Never misrepresent passthrough as specialized cognition. Do not claim 98 fully implemented merely because 98 dispatch slots exist. The builder may incrementally implement additional functions, but must prove each via nontrivial behavioral tests and negative cases. Prioritize end-to-end function usefulness over arbitrary slot-count inflation.

## 4. Exact 2,208-position memory layout

Big49 indices 0–1599: `cognitive` 1,280 positions × 512-character experimental cap; `association` 320 × 512. The Big49 cap is an experimental candidate, **not recovered historical canon**.

Small49 indices 1600–2207, 608 total:

| Bucket | Positions | Character cap |
|---|---:|---:|
| history | 256 | 512 |
| active | 64 | 512 |
| workspace_micro | 24 | 64 |
| workspace_medium | 40 | 250 |
| workspace_large | 64 | 500 |
| bridge_macro | 10 | 1000 |
| bridge_projection | 40 | 500 |
| bridge_path | 20 | 250 |
| bridge_typed | 60 | 128 |
| bridge_pointer | 30 | 64 |

Source `realcog/ph6_brains_2208.py` uses SQLite, pool/bucket quotas, versioned records, digesting and an audit event chain. Inspect its exact `MemoryStore`, `Pointer`, `Block` and adapter interfaces. Preserve block IDs and mappings. Require real write/read/restart tests for every bucket family; test quota exhaustion, oversized payloads, wrong owners, invalid pointers, integrity mismatch, simultaneous writers and partial writes. Publish counts separately: configured, allocated, populated, retrieved, and **causally used** by cognitive outcomes.

## 5. CRAM-PU and durability

Source `crampu/controller.py` and `crampu/build030_bridge.py`. Existing default HOT LRU: 256 entries, 1,048,576 bytes. WARM JSON snapshot uses exclusive temporary file creation, fsync and atomic replace; inspect directory fsync and crash semantics. COOL SQLite uses WAL, `synchronous=FULL`, owners/blocks/transitions/outbox; outbox states `PENDING → APPLIED → ACKNOWLEDGED`. COOL record digests are checked on reload. Bridge mirrors committed data to Big49/Small49 and applies Suit OD-05 causal checks.

**Build 42.0 requirement:** document and test the actual ordering of COOL commit, outbox stage, mirror apply, acknowledgement and recovery. Test kill/restart at each boundary, idempotent replay, duplicate deliveries, malformed payloads, corruption, ownership conflict, disk-full, and permission denial. Distinguish simulated process interruption from physical power-loss certification. Do not give the Orange Pi direct access to the CRAM database or admin token. Do not assume an in-memory HOT hit is durable.

## 6. Suit / Closet / Continuity security boundaries

`SoSoSuitRuntime` currently tracks `AgentGrant(agent_id, capabilities, allowed_block_ids, max_steps, max_payload_bytes, steps_used, revoked, terminated, parent_agent_id, created_ns)`. `authorize_agent` validates an L01–L49 principal through `build030_suit_capability_check`; `request_child_agent` checks subset capabilities and block scope; `execute_memory_write/read` check grants and block scope; `revoke_agent`, `terminate_agent`, `audit_log` exist. Audit the child lifecycle, grant replacement, negative budgets, parent revocation propagation, time-of-check/time-of-use and persistence across restart. The current `_grants` dictionary is in-memory, so restart revocation semantics require explicit qualification or design changes. **A child's authority must never exceed its parent and no agent may mint Lane-1 evidence authority.**

`SoSoCloset` currently exposes `submit_task`, `retrieve_context`, `invoke_agent`, `request_memory`, `collect_results`, `audit_log`; its `invoke_agent` presently performs a Suit-governed memory write, not a general agent task executor. Build 42.0 must introduce a real bounded task invocation/return contract and prove it works. Do not silently rename memory writes as full autonomous agent execution.

`SoSoContinuity` persists `sessions`, `events`, `experience_index` in SQLite. Event kinds include `OBSERVATION`, `CLAIM`, `INTERPRETATION`, `MODEL_OUTPUT`, `VERIFIED_RESULT`, `ROUTING_DECISION`, `EXPERIENCE_REF`. An event kind named `VERIFIED_RESULT` does not by itself prove external validity. Test ordering, restart recovery, duplicate IDs, provenance, read isolation and tamper detection.

## 7. Learning: the non-negotiable Build 42.0 experiment

`AssistedLearningLoop.run_unassisted` uses U13 (candidate filter), U11 (partitions), optional Suit memory read, U15 (transfer), U12 (selection). Its memory-read exception handler currently catches **all** exceptions and continues silently. This can hide permission failures or corruption; fix with explicit failure classification and provenance.

`assist_and_learn` takes a **caller-supplied history** and calls U14 to select a profile; optionally logs an AI-generated hint; persists the profile through Suit. The AI hint is not shown to causally change U14's selection in the inspected source. This demonstrates bounded profile selection and storage, not independently proven autonomous learning. The builder must add an internally generated experience→feedback→profile-update loop, with training/holdout isolation and measurable improvement on unseen problems.

`ExperienceEngine` has a deterministic diagnostic probe fixture with probe order thermal, pressure, voltage; its reported four-arm ablation contrasts with-memory, without-memory, irrelevant-memory and corrupted-memory. This establishes a bounded memory-use effect, not broad generalization. Source reports 1 probe with relevant memory versus 3 in other conditions; independently re-run and check how fixture design constrains the result.

**Required experiment protocol:**
1. Freeze problem generator, answer oracle, test seeds, train/validation/test splits and task definitions before training.
2. Run a cold baseline with memory disabled and no prior exposure to test answers.
3. Allow experience collection and outcome feedback **only** on training tasks.
4. Run the same held-out evaluation after learning, with external AI disabled. Compare accuracy, task completion, steps, wall-clock latency, cost, and confidence calibration as applicable.
5. Restart the processes and repeat evaluation to verify persistence.
6. Run ablations: memory disabled, shuffled/wrong memory, corrupted memory, learning disabled, and gateway-only controls.
7. Run a genuinely novel task-family transfer set distinct from the training task templates.
8. Repeat over multiple fixed seeds and disclose variance, uncertainty, failures and effect sizes.
9. Repeat with online AI enabled and separately report whether improvement depends on AI-generated hints.
10. Record every training event, policy/profile version, memory read, memory write, decision and feedback linkage.

**Acceptance:** a statistically and operationally meaningful held-out improvement attributable to accumulated experience, persisting across restart and degrading under relevant ablation. If absent, report `LEARNING_NOT_DEMONSTRATED` rather than a fabricated PASS. No training on evaluation answers, no oracle leakage, no fixed task memorization masquerading as transfer.

## 8. AI gateway and provider isolation

`build040_runtime/online_ai.py` provides `GoogleGeminiProvider` (default model `gemini-2.5-flash`, env `GEMINI_API_KEY`), `OpenAIProvider` (default `gpt-4o-mini`, env `OPENAI_API_KEY`), `ReplayProvider` (SHA-256 prompt-keyed), `OfflineAdvisoryProvider`, and `OnlineAIGateway` with retries/backoff/fallback. Defaults are **historical source values, not a guarantee of present provider availability**. Keys must come from runtime secrets, never be committed. The source constructs a Gemini URL with the API key in the query string; evaluate key exposure through logs and transport diagnostics. Source token-cost estimates are rough placeholders, not provider billing truth. Gateway failures must not silently turn AI advice into authority. Enforce per-task timeouts, provider-independent structured output validation, bounded token and cost budgets, provenance, deterministic replay and offline operation. Record when fallback occurred.

## 9. Precision-105, historical fixtures, and evaluation

`build040_runtime/precision_105.py`, `precision_105_grader.py`, `BUILD040_P105_FUNCTION_TRACE.json`, historical fixture ZIPs and test sources establish structural/chronology and replay tests. Source disclosure reports 13 consecutive chronology checks, 104 trace steps across eight functions plus U09, and 31.994 ms elapsed in a bounded `p105-official-run` trace; do not generalize this to original historical prose generation. Source disclosure explicitly states original historical prose generation was **blocked offline** without a live model or suitable local generator. Validate exact anchor constraints, word-count limits, provenance and public-vs-private grading separation. Never embed private answer keys in a public test bundle.

## 10. Pi 5 + Orange Pi Zero 2W dual-node plan

**Pi 5:** authoritative host for standalone runtime, SoSo Closet, Suit, 49 Brains, memory and continuity. **Orange Pi Zero 2W:** independent test author/grader, adversarial probe runner, result signer/log keeper, optional telemetry collector. The Orange Pi must not become a privileged writer to Pi 5 SQLite, Suit grants, PH6 evidence or raw CRAM storage.

Existing `build040_runtime/grader_endpoint.py` exposes `GET /grader/health` and `POST /grader/submit`, uses `X-Grader-Token` with `hmac.compare_digest`, and invokes `SoSoCloset.submit_task` then `invoke_agent`. `deploy/orangepi/orangepi_grader.py`, `pyrit_grader_target.py`, `deploy/pi5/promptfoo_grader_config.yaml`, and Pi systemd scripts are source examples. Existing endpoint has no explicit request-body size limit, accepts JSON without comprehensive error handling, and its submit operation can cause a Suit-authorized memory write; do **not** expose it on a public network without hardening. Promptfoo YAML and PyRIT adapter existence do not prove those frameworks were executed. Provide a least-privilege, bounded grading API with replay-resistant challenge IDs, strict schemas, request limits, deadlines, result provenance, and isolated test state. Keep raw attack prompts as untrusted data.

Implement Pi install/upgrade/rollback, service user permissions, separate state directories, structured logs, systemd unit files, backup/restore, time synchronization handling and network failure recovery. Prefer offline local qualification first. Physical Pi execution and power-loss qualification remain **UNVERIFIED** until run on the actual devices.

## 11. Known evidence and gaps

**Source-provided reports (not all independently rerun):** Build 040 analysis JSON reports 61/61 unit tests; qualification_030 22/22; an earlier qualification evidence file reports 53/53 and Orange Pi 20-iteration local simulation. Earlier review independently reported 25 targeted test passes (20 integration + 4 interrogation + 1 learning), but the builder must re-execute on its own environment and attach raw output. Different test counts refer to different test selections or package states and must not be added or conflated.

**Known gaps:** 77 default-routed function slots; no broad autonomous cognition proven; externally supplied history in U14 learning path; AI hint causality not established; no demonstrated live Gemini/OpenAI call; no Pi 5 / Orange Pi hardware acceptance; no physical power-loss durability; no broad saturation/performance benchmarking; no full adversarial security qualification; no proof of end-to-end historical prose generation offline; no proof of production readiness.

## 12. Required Build 42.0 release artifacts

Return a **real source ZIP** `SUIT_AND_BRAINS_42_0.zip` containing complete Python source, versioned interfaces, schemas, tests, offline fixtures, install scripts, Pi 5 and Orange Pi service configs, test runner, and deterministic evaluation harness. Also return `BUILD42_EXECUTION_EVIDENCE.json` with environment, commands, exit codes, test counts, benchmark seeds, artifact hashes and actual measured outputs; `BUILD42_98_FUNCTION_REGISTRY.json` with verified status for all 98; `BUILD42_MEMORY_USAGE.json`; `BUILD42_LEARNING_RESULTS.json`; `BUILD42_SECURITY_TESTS.json`; `BUILD42_SOURCE_CHANGELOG.json`; and `BUILD42_DEPLOYMENT_STATUS.json` distinguishing simulated vs physical device qualification. Use complete runnable code, no TODO placeholders or fake success.

**Baseline regression commands** (run in an extracted source root; adapt for version and dependencies):

```bash
python3 -m unittest discover -s tests -p 'test_build040_integration_20.py' -v
python3 -m unittest discover -s tests -p 'test_ai_interrogation_protocols.py' -v
python3 -m unittest discover -s tests -p 'test_learning_loop_u11_u15.py' -v
python3 -m qualification_030.verify --output /tmp/build42-qualification-unique
```

Inspect test filenames in the source tree before executing. Use a fresh qualification output directory. Run full supported unittest and pytest selections where dependencies exist; preserve failure logs. Add 42.0-specific tests for security, restart, crash boundaries, 98-slot disclosure, memory bucket coverage, actual task invocation, independent grader and held-out learning.

**Acceptance gates:** G0 source identity/reconciliation; G1 import/install + baseline regressions; G2 all 98 slots accurately disclosed and supported subset behaviorally exercised; G3 Big/Small memory durability + ownership; G4 Suit/Closet capability isolation; G5 SoSo continuity and restart; G6 learning benchmark with negative controls; G7 provider offline/replay/live status; G8 Pi/Orange dual-node local simulation; G9 deployment security and rollback; G10 physical hardware qualification (separate gate, may remain pending). Every gate must carry `PASS`, `FAIL`, `BLOCKED`, or `NOT_RUN` with raw evidence. Do not label the release fully qualified if any required production gate is unexecuted.

## 13. Execution priority and dependency triage

**Class 1** hard blockers to the specific dependent step: readable baseline source, runnable Python runtime, correct storage/auth boundaries, deterministic test harness, safe secret handling, correct evaluation oracle, essential hardware for *physical* acceptance only. **Class 2** eventual requirements that need not block code construction: Pi deployment qualification, production monitoring, high-volume soak tests, live provider API testing. **Class 3** supplementary: complete historical narrative recovery, cosmetic dashboards, optional accelerators, additional provider adapters. Never turn missing Class 2/3 history into a global stop condition.

## 14. Explicit no-go claims

Do not claim: all 98 functions implement cognition; all 2,208 memory positions are populated; storage proves learning; passing fixtures prove general intelligence; the Orange Pi is already physically deployed; networked model calls are verified; promptfoo/PyRIT are proven end-to-end merely by adapter presence; Build 42.0 has PH6 Lane-1 authority; a source comment is equivalent to a test; or 42.0 is production-ready without measured operational evidence.

## 15. Deliverable behavior

Start by reading the attached ZIPs and JSON/CSV registries, not by requesting a prose recap. Then **write and test the actual Build 42.0 code**. Preserve old source and provenance in a separate archive or version control history. Report exact changed files, interfaces, tests and residual gaps. If execution is blocked by missing tools, complete all feasible implementation and identify the precise missing gate. The operator wants a functioning build, not a governance loop.


# REVISION 2 — REQUIRED DIAGRAM RECONCILIATION

Before implementation, inspect both images in `DIAGRAMS/` and read `DIAGRAMS/SOURCE_COMPARISON.md` and `.json`. Treat images as user-supplied Build 040 conceptual diagrams, not a verified linear call graph or Build 42.0 implementation. The source-level comparison records 13 explicit observations. Preserve original images and record any source contradictions. In particular: Closet calls Suit directly; LearningLoop U14 consumes supplied `history` and does not receive the AI hint as a causal input; learned-profile storage does not prove capability improvement. Do not delete, replace, or silently simplify the existing Build 040/040.1 source or PH6 boundaries. Add integration and causal learning tests before claiming Build 42.0 qualification.
